import { DatePipe } from '@angular/common';
import { Component, OnInit } from '@angular/core';
import { Shouts } from 'src/app/models/shouts';
import { ShoutsService } from 'src/app/shouts.service';
import { UserService } from 'src/app/user.service';

@Component({
  selector: 'app-user-home',
  templateUrl: './user-home.component.html',
  styleUrls: ['./user-home.component.scss'],
})
export class UserHomeComponent implements OnInit {
  shouts: Shouts = new Shouts();
  DateCreated!: any;

  constructor(
    private shoutService: ShoutsService,
    private datePipe: DatePipe
  ) {}

  ngOnInit(): void {}

  uploadPost() {
    this.shouts.ShoutsId = 1;
    console.log('hi');
    console.log(this.shouts);
    // let strDate = this.datePipe.transform(this.DateCreated, 'yyyy-MM-dd');
    // if (strDate != null) {
    //   this.shouts.DateCreated = strDate;
    // }
    this.shoutService.UploadShout(this.shouts).subscribe(
      (response) => {
        alert('new shout ' + this.shouts.ShoutsId + ' has been created !!!');
      },
      (error) => console.log('error', error)
    );
  }
}
