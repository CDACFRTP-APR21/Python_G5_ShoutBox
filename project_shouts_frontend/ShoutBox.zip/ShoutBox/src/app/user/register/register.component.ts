import { Component, OnInit } from '@angular/core';
import { UserService } from 'src/app/user.service';

@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.scss'],
})
export class RegisterComponent implements OnInit {
  user = {
    UserId: 3,
    UserName: 'Nehal',
    FirstName: 'Nehal',
    LastName: 'Kulkarni',
    Email: 'Nehalku@cybage.com',
    MobileNo: '8177949826',
    Password: '1234',
  };

  constructor(private userService: UserService) {}

  ngOnInit(): void {
    this.userService.registerUser(this.user).subscribe();
  }
}
