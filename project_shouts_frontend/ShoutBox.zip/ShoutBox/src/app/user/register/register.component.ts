import { Component, OnInit } from '@angular/core';
import { UserService } from 'src/app/user.service';
import { User } from 'src/app/models/user';
import { DatePipe } from '@angular/common';

@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.scss'],
})
export class RegisterComponent implements OnInit {
  // user = {
  //   UserId: 3,
  //   UserName: 'Nehal',
  //   FirstName: 'Nehal',
  //   LastName: 'Kulkarni',
  //   Email: 'Nehalku@cybage.com',
  //   MobileNo: '8177949826',
  //   Password: '1234',
  // };

  user: User = new User();
  ConfirmPassword!: string;
  DateOfBirth!: any;

  constructor(private userService: UserService, private datePipe: DatePipe) {}

  ngOnInit(): void {}

  registerNewUser() {
    this.user.UserId = 3;
    console.log('in register new user');
    console.log(this.user);
    let strDate = this.datePipe.transform(this.DateOfBirth, 'yyyy-MM-dd');
    if (strDate != null) {
      this.user.DateOfBirth = strDate;
    }
    this.userService.registerUser(this.user).subscribe((response) => {
      console.log(response);
    });
  }
}
