export class UserTimeline {
  ShoutsId!: number;
  UserId!: number;
  DateCreated!: any;
  TextContent!: string;
  File!: any;
  FileType!: string;
  FirstName!: string;
  LastName!: string;
  ProfilePicURL!: any;
  IsDeleted!: boolean;
}
