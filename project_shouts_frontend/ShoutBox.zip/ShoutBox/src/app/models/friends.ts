export class Friends {
  User1Id!: number;
  User2Id!: number;
  StatusCode!: number;
  ActionUserId!: number;
}
