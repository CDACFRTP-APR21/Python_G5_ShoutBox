export class Friends {
  DateCreated: any;
  DateOfBirth: any;
  Email!: string;
  FirstName!: string;
  Gender!: any;
  IsActive!: boolean;
  LastName!: string;
  MobileNo!: number;
  Password!: string;
  ProfilePicURL!: any;
  UserName!: string;
  UserId!: number;
  StatusCode!:number;
  ActionUserId!:number;
}
