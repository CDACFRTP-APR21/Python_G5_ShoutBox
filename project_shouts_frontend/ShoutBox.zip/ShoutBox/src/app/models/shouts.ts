export class Shouts {
  ShoutsId!: number;
  UserId!: number;
  DateCreated!: any;
  File!: any;
  TextContent!: string;
  FileType!: any;
  IsDeleted!: boolean;
}
