export class Shouts {
  ShoutsId!: number;
  UserId!: number;
  DateCreated!: string;
  TextData!: string;
  FileData!: string;
  IsDeleted!: boolean;
}
