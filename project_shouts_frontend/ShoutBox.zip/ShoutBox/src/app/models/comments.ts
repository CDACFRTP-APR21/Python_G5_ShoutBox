export class Comments {
  CommentId!: number;
  ShoutsId!: number;
  UserId!: number;
  CommentContent!: string;
  DateCreated!: any;
  FirstName!: string;
  LastName!: string;
  ProfilePicURL!: any;
}
