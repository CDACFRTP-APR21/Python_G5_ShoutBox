export class Comments {
  CommentId!: number;
  ShoutsId!: number;
  UserId!: number;
  CommentContent!: string;
  DateCreated!: string;
  FirstName!: string;
  LastName!: string;
  ProfilePicURL!: any;
}
