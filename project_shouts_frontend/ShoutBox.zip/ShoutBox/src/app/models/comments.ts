export class Comments {
  CommentId!: number;
  ShoutsId!: number;
  UserId!: number;
  CommentContent!: string;
  DateCreated!: string;
}
