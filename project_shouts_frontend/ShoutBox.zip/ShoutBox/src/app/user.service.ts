import { Injectable } from '@angular/core';

import { HttpClient } from '@angular/common/http';
import { observable } from 'rxjs';

@Injectable({
  providedIn: 'root',
})
export class UserService {
  readonly url = 'http://127.0.0.1:8000/user/';

  constructor(private http: HttpClient) {}

  registerUser(val: any) {
    console.log('in user service');
    return this.http.post(this.url, val);
  }
}
